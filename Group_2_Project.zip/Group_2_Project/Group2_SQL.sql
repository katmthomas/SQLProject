## syntax create tables and corresponding drop##

use group2_database;

CREATE TABLE animals (
aID INT NOT NULL,
aAge INT,
aname varchar(50) NOT NULL,
aintakedate DATE,
acolor VARCHAR(20),
aweight INT NOT NULL, 
aAdoptionprice INT NOT NULL,
aorigin VARCHAR(50) NOT NULL,
afoster VARCHAR(10),
PRIMARY KEY (aID)
);
#DROP TABLE animals;
CREATE TABLE breed (
breedID INT NOT NULL,
bsize VARCHAR(50) NOT NULL,
aID INT NOT NULL,
btype VARCHAR(50) NOT NULL,
PRIMARY KEY (breedID, aID),
FOREIGN KEY (aID) REFERENCES animals(aID)
);

#DROP TABLE breed;
CREATE TABLE owners (
oID INT NOT NULL,
ofname VARCHAR(50) NOT NULL,
olname VARCHAR(50) NOT NULL,
address VARCHAR(100) NOT NULL,
phonenumber CHAR (12), 
email VARCHAR(320),
aID INT,
PRIMARY KEY (oID),
FOREIGN KEY (aID) REFERENCES animals(aID)
);
#ALTER TABLE owners DROP CONSTRAINT owners_ibfk_1;
#DROP TABLE owners;

CREATE TABLE opprotunities (
opprotunityID INT NOT NULL,
oname VARCHAR(150) NOT NULL,
vID INT NOT NULL,
PRIMARY KEY (opprotunityID),
FOREIGN KEY (vID) REFERENCES volunteers(vID)
);
#DROP TABLE opprotunities;
#ALTER TABLE opprotunities DROP CONSTRAINT opprotunities_ibfk_1;

CREATE TABLE volunteers (
vID INT NOT NULL,
vfname VARCHAR(50),
vlname VARCHAR(50),
vphone CHAR(12),
vemail VARCHAR(320),
PRIMARY KEY (vID)
);
#DROP TABLE volunteers;

CREATE TABLE foster (
fID INT NOT NULL,
aID INT,
vID int NOT null,
PRIMARY KEY (fID,vID),
FOREIGN KEY (aID) REFERENCES animals(aID),
FOREIGN KEY (vID) REFERENCES volunteers(vID)
);
# DROP TABLE foster;
CREATE TABLE signup (
signupID int,
signupdate DATE,
timeslot int,
vID INT,
opprotunityid int,
PRIMARY KEY (signupID),
FOREIGN KEY (vID) references volunteers(vID),
FOREIGN KEY (opprotunityID) references opprotunities(opprotunityID)
);
ALTER TABLE signup
MODIFY COLUMN signupID int NOT NULL;

#fostersignupALTER TABLE signup DROP CONSTRAINT signup_ibfk_1;
#ALTER TABLE signup DROP CONSTRAINT signup_ibfk_2;
#DROP TABLE foster;




# POPULATING TABLES #
select * from animals;
# animals table#
insert into animals (aID,aAge,aname,aintakedate,acolor,aweight,aAdoptionprice,aorigin,afoster) 
values (184, 1,'Perry','2021-08-10','black', 8, 35,'forfeiture','yes');
insert into animals (aID,aAge,aname,aintakedate,acolor,aweight,aAdoptionprice,aorigin,afoster) 
values (132, 2,'Mickey', '2021-09-12', 'black and white', 12, 60, 'abandoned', 'yes');
insert into animals (aID,aAge,aname,aintakedate,acolor,aweight,aAdoptionprice,aorigin,afoster) 
values (738, 9,'Roxie', '2021-06-27', 'black', 10, 70, 'shelter intake', 'no');
insert into animals (aID,aAge,aname,aintakedate,acolor,aweight,aAdoptionprice,aorigin,afoster) 
values (342, 13,'Goldie', '2021-10-10', 'white', 55, 45, 'abandoned', 'no');
insert into animals (aID,aAge,aname,aintakedate,acolor,aweight,aAdoptionprice,aorigin,afoster) 
values (843, 4,'Pumpkin', '2021-07-19', 'orange', 11, 60, 'forfeiture', 'no');
insert into animals (aID,aAge,aname,aintakedate,acolor,aweight,aAdoptionprice,aorigin,afoster) 
values (039, 1,'Kevin', '2021-11-05', 'white', 35, 75, 'forfeiture', 'yes');
insert into animals (aID,aAge,aname,aintakedate,acolor,aweight,aAdoptionprice,aorigin,afoster) 
values (538, 17,'Stella', '2021-09-11', 'white', 8, 35, 'shelter intake', 'no');
insert into animals (aID,aAge,aname,aintakedate,acolor,aweight,aAdoptionprice,aorigin,afoster) 
values (392, 5,'Biscuit', '2021-10-31', 'black and white', 45, 40, 'abandoned', 'no');
insert into animals (aID,aAge,aname,aintakedate,acolor,aweight,aAdoptionprice,aorigin,afoster) 
values (189, 5,'Cherry', '2021-08-24', 'brown', 60, 50, 'shelter intake', 'no');
insert into animals (aID,aAge,aname,aintakedate,acolor,aweight,aAdoptionprice,aorigin,afoster) 
values (493, 20,'Mittens', '2021-10-24', 'orange', 13, 15, 'abandoned', 'no');


# breed table #
select * from breed;

insert into breed (breedID, bsize, aID, btype)
values (11, 'small', 184, 'cat');
insert into breed (breedID, bsize, aID, btype)
values (12, 'medium', 132, 'cat');
insert into breed (breedID, bsize, aID, btype)
values (11, 'small', 738, 'cat');
insert into breed (breedID, bsize, aID, btype)
values (17, 'medium', 342, 'dog');
insert into breed (breedID, bsize, aID, btype)
values (11, 'small', 843, 'cat');
insert into breed (breedID, bsize, aID, btype)
values (18, 'large', 032, 'dog');
insert into breed (breedID, bsize, aID, btype)
values (3, 'small', 538, 'dog');
insert into breed (breedID, bsize, aID, btype)
values (82, 'medium', 392, 'dog');
insert into breed (breedID, bsize, aID, btype)
values (56, 'large', 189 , 'dog');
insert into breed (breedID, bsize, aID, btype)
values (11, 'small', 493, 'cat');

# volunteers table#
select * from volunteers;
insert into volunteers (vID,vfname,vlname,vphone,vemail)
values (1, 'Elijah','Smith', 5045278910, 'elsmith@gmail.com');
insert into volunteers (vID,vfname,vlname,vphone,vemail)
values (2,'Noah','Johnson',	5045278911, 'njohnson1@gmail.com');
insert into volunteers (vID,vfname,vlname,vphone,vemail)
values (10,'Amelia','Taylor',5045278919,'ameliat@gmail.com'
);
insert into volunteers (vID,vfname,vlname,vphone,vemail)
values (16,'Evelyn','Martinez',5045278925,'evelynm@gmail.com'
);
insert into volunteers (vID,vfname,vlname,vphone,vemail)
values (25,'Eli','Whitney',5045278934,'eliwhit@gmail.com'
);
insert into volunteers (vID,vfname,vlname,vphone,vemail)
values (13,'Charlotte','Jackson',5045278922, 'charjackson@gmail.com'
);
insert into volunteers (vID,vfname,vlname,vphone,vemail)
values (9, 'Oliver','Moore',5045278918, 'olivmoore@gmail.com'
);

# foster table#
select * from foster;
insert into foster (fID,aID,vID)
values (12, 184, 13);
insert into foster (fID,aID,vID)
values (45, 132, 9);
insert into foster (fID,aID,vID)
values (34, 032, 1);

# opprotunities table #
insert into opprotunities (opprotunityID,oname,vID)
values (243, 'transport', 1);
insert into opprotunities (opprotunityID,oname,vID) 
values (342, 'transport', 1);
insert into opprotunities (opprotunityID,oname,vID)
values (479, 'dog walk', 1);
insert into opprotunities (opprotunityID,oname,vID)
values (323, 'dog walk', 9);
insert into opprotunities (opprotunityID,oname,vID)
values (409, 'dog walk', 9);
insert into opprotunities (opprotunityID,oname,vID)
values (129, 'dog walk', 9);
insert into opprotunities (opprotunityID,oname,vID)
values (201, 'Petco', 9);
insert into opprotunities (opprotunityID,oname,vID)
values (456, 'in house', 9);
insert into opprotunities (opprotunityID,oname,vID)
values (986, 'adoption event', 13);
insert into opprotunities (opprotunityID,oname,vID)
values (274, 'in house', 13);
insert into opprotunities (opprotunityID,oname,vID)
values (542, 'adoption event', 2);
insert into opprotunities (opprotunityID,oname,vID)
values (507, 'in house', 2);
insert into opprotunities (opprotunityID,oname,vID)
values (535, 'in house', 2);
insert into opprotunities (opprotunityID,oname,vID)
values (985, 'in house', 2);
insert into opprotunities (opprotunityID,oname,vID)
values (095, 'other', 1);
insert into opprotunities (opprotunityID,oname,vID)
values (076, 'other', 9);
insert into opprotunities (opprotunityID,oname,vID)
values (016, 'other', 13);
insert into opprotunities (opprotunityID,oname,vID)
values (054, 'in house', 25);
insert into opprotunities (opprotunityID,oname,vID)
values (975, 'adoption event', 16);
insert into opprotunities (opprotunityID,oname,vID)
values (834, 'in house', 10);
insert into opprotunities (opprotunityID,oname,vID)
values (713, 'in house', 25);
insert into opprotunities (opprotunityID,oname,vID)
values (304, 'transport', 25);
insert into opprotunities (opprotunityID,oname,vID)
values (923, 'Petco', 16);
insert into opprotunities (opprotunityID,oname,vID)
values (700, 'dog walk', 16);
insert into opprotunities (opprotunityID,oname,vID)
values (800, 'in house', 10);
insert into opprotunities (opprotunityID,oname,vID)
values (820, 'in house', 10);
insert into opprotunities (opprotunityID,oname,vID)
values (817, 'adoption event', 10);

# owners table #
insert into owners (oID,ofname,olname,address,phonenumber,email,aID)
values (012, 'Betty', 'White', '123 State St.', 5048763409, 'bwhite@gmail.com', 843);
insert into owners (oID,ofname,olname,address,phonenumber,email,aID)
values (047, 'Michael', 'Smith', '1814 Audubon St.', 5048324890, 'mj@gmail.com', 738);


# signup table #
select * from signup;

insert into signup (signupID,signupdate,timeslot,vID,opprotunityid)
values (01, '2021-09-28', 'morning', 1,243);
insert into signup (signupID,signupdate,timeslot,vID,opprotunityid)
values (02, '2021-10-01', 'morning', 1,342);
insert into signup (signupID,signupdate,timeslot,vID,opprotunityid)
values (03, '2021-10-07', 'afternoon', 1,479);
insert into signup (signupID,signupdate,timeslot,vID,opprotunityid)
values (04, '2021-09-01', 'morning', 9,323);
insert into signup (signupID,signupdate,timeslot,vID,opprotunityid)
values (05, '2021-09-15', 'morning', 9,409);
insert into signup (signupID,signupdate,timeslot,vID,opprotunityid)
values (06, '2021-09-03', 'morning', 9,129);
insert into signup (signupID,signupdate,timeslot,vID,opprotunityid)
values (07, '2021-10-15', 'evening', 9,201);
insert into signup (signupID,signupdate,timeslot,vID,opprotunityid)
values (08, '2021-10-25', 'afternoon', 9,456);
insert into signup (signupID,signupdate,timeslot,vID,opprotunityid)
values (09, '2021-10-18', 'morning', 13, 986);
insert into signup (signupID,signupdate,timeslot,vID,opprotunityid)
values (10, '2021-09-21', 'evening', 13,274);
insert into signup (signupID,signupdate,timeslot,vID,opprotunityid)
values (11, '2021-09-21', 'morning', 2,542);
insert into signup (signupID,signupdate,timeslot,vID,opprotunityid)
values (12, '2021-11-01', 'morning', 2,507);
insert into signup (signupID,signupdate,timeslot,vID,opprotunityid)
values (13, '2021-10-06', 'evening', 2,535);
insert into signup (signupID,signupdate,timeslot,vID,opprotunityid)
values (14, '2021-09-26', 'evening', 2,985);
insert into signup (signupID,signupdate,timeslot,vID,opprotunityid)
values (15, '2021-09-21', 'morning', 1,095);
insert into signup (signupID,signupdate,timeslot,vID,opprotunityid)
values (16, '2021-10-07', 'morning', 9,076);
insert into signup (signupID,signupdate,timeslot,vID,opprotunityid)
values (17, '2021-10-12', 'morning', 13,016);
insert into signup (signupID,signupdate,timeslot,vID,opprotunityid)
values (18, '2021-11-08', 'afternoon', 25,054);
insert into signup (signupID,signupdate,timeslot,vID,opprotunityid)
values (19, '2021-11-08', 'afternoon', 16,975);
insert into signup (signupID,signupdate,timeslot,vID,opprotunityid)
values (20, '2021-11-03', 'afternoon', 10,834);
insert into signup (signupID,signupdate,timeslot,vID,opprotunityid)
values (21, '2021-11-08', 'afternoon', 25,713);
insert into signup (signupID,signupdate,timeslot,vID,opprotunityid)
values (22, '2021-10-29', 'afternoon', 25, 304);
insert into signup (signupID,signupdate,timeslot,vID,opprotunityid)
values (23, '2021-10-30', 'evening', 16, 923);
insert into signup (signupID,signupdate,timeslot,vID,opprotunityid)
values (24, '2021-09-19', 'afternoon', 16,700);
insert into signup (signupID,signupdate,timeslot,vID,opprotunityid)
values (25, '2021-10-10', 'morning', 10,800);
insert into signup (signupID,signupdate,timeslot,vID,opprotunityid)
values (26, '2021-11-02', 'morning', 10,820);
insert into signup (signupID,signupdate,timeslot,vID,opprotunityid)
values (27, '2021-09-10', 'evening', 10,817);

# select statements #
select * from animals;
select * from breed;
select * from foster;
select * from volunteers;
select * from owners;
select * from signup;
select * from opprotunities;

# Queries #

#Q1 Identify the ID, name, and intake date  of the three oldest animals at the shelter
SELECT aID, aname, aintakedate, aAge
FROM animals
ORDER BY aAge DESC
LIMIT 3;

#Q2 We are trying to determine which opprotunity times are the least scheduled. We will use the data to send out emails encouraging volunteers to sign up for the least popular time slot.
# Identify the most frequently scheduled time for these opprotunities, so the least scheduled can be promoted more to volunteers
SELECT o.oname, s.timeslot, count(s.timeslot) as Numberofsignups
FROM signup s, opprotunities o 
WHERE s.opprotunityid = o.opprotunityID
GROUP BY o.oname, s.timeslot
ORDER BY Numberofsignups;

#Q2 Pt 2: We want to invite volunteers who have not signedup for in house and dog walking opprotunities, who do we contact?
# List volunteer ID, first and last name, email, and what timeslots they have signed up for before
SELECT v.vID, v.vfname, v.vlname, v.vemail, s.timeslot
FROM ((opprotunities op
INNER JOIN volunteers v on op.vID = v.vID)
INNER JOIN signup s on op.opprotunityID = s.opprotunityid)
WHERE op.oname != "in house" AND op.oname != "dog walk"
GROUP BY s.timeslot, v.vfname, v.vlname;

#Q3 How many cats do we have in the shelter, include aID, aname, and order by weight descending
SELECT a.aID, a.aname, a.aweight, b.btype
FROM animals a, breed b
WHERE a.aID = b.aID
AND btype = "cat"
ORDER BY a.aweight DESC;

#Q3 How many dogs do we have at the shelter include aID, aname, size, and order by weight descending
SELECT a.aID, a.aname, a.aweight, b.btype, b.bsize
FROM animals a, breed b
WHERE a.aID = b.aID
AND btype = "dog"
ORDER BY a.aweight DESC;

#Q4 We are trying to identify which volunteers are fostering which animals.
# Please find volunteer first name, last name, vID, fosterID and the name, age, ID of the animals being fostered
#Sort by animal name in alphabetical order
SELECT f.fID, f.vID, v.vfname, v.vlname, f.aID, a.aname, a.aAge
FROM ((foster f 
INNER JOIN volunteers v ON f.vID = v.vID)
INNER JOIN animals a ON f.aID = a.aID)
ORDER BY a.aname;

#Q5 We are trying to update our database, what animals have been adopted?
#Include animal ID, name, aAdoptionprice, owner first and last name, and owner ID
SELECT a.aID, a.aname, a.aAdoptionprice, o.oID, o.ofname, o.olname
FROM animals a, owners o
WHERE a.aID = o.aID
GROUP BY a.aID;

#Q6 What is the most popular volunteer opprotunity? 
SELECT count(oname) as NumberofSignups, oname
FROM opprotunities
GROUP BY oname
ORDER BY NumberofSignups DESC
LIMIT 1;

#Q7 What is the average weight of animals classified as "small" breed size? Group by the type of animal
SELECT AVG(a.aweight) as averageweight, b.btype
FROM animals a, breed b
WHERE a.aID = b.aID
AND b.bsize = "small"
GROUP BY b.btype;

#Q8 What animal has been at the shelter the longest? Include all columns in the animals table
SELECT *
FROM animals
ORDER BY aintakedate 
LIMIT 1;

#Q9 Please list the total number of animals brought to the shelter by origin.
SELECT COUNT(*) as Totalanimals, aorigin
FROM animals
GROUP BY aorigin;

#Q10 Identify how many animals belong to each animal color. Order by most common to least common
SELECT count(*) as Totalpercolor, acolor
FROM animals
GROUP BY acolor
ORDER BY Totalpercolor DESC;








